/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Leaf, 
  Car, 
  Zap, 
  Trash2, 
  Plane, 
  Utensils, 
  ChevronRight, 
  ChevronLeft, 
  TrendingDown, 
  Wallet, 
  Globe,
  ArrowRight,
  Info,
  CheckCircle2
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip 
} from 'recharts';
import { cn } from './lib/utils';
import { CarbonData, FootprintResult } from './types';
import { calculateFootprint } from './services/calculator';

const STEPS = [
  { id: 'welcome', title: 'Welcome' },
  { id: 'transport', title: 'Transport', icon: Car },
  { id: 'diet', title: 'Diet', icon: Utensils },
  { id: 'energy', title: 'Energy', icon: Zap },
  { id: 'waste', title: 'Waste', icon: Trash2 },
  { id: 'flights', title: 'Flights', icon: Plane },
  { id: 'results', title: 'Results' },
  { id: 'marketplace', title: 'Marketplace' },
];

const INITIAL_DATA: CarbonData = {
  transport: { type: 'car', distance: 100, isElectric: false },
  diet: { type: 'meat' },
  energy: { electricity: 200, gas: 10 },
  waste: { recycleLevel: 'partial' },
  flights: { hours: 5 },
};

export default function App() {
  const [stepIndex, setStepIndex] = useState(0);
  const [data, setData] = useState<CarbonData>(INITIAL_DATA);
  const currentStep = STEPS[stepIndex];

  const results = useMemo(() => calculateFootprint(data), [data]);

  const nextStep = () => setStepIndex((prev) => Math.min(prev + 1, STEPS.length - 1));
  const prevStep = () => setStepIndex((prev) => Math.max(prev - 1, 0));

  const updateData = (section: keyof CarbonData, values: any) => {
    setData((prev) => ({
      ...prev,
      [section]: { ...prev[section], ...values },
    }));
  };

  return (
    <div className="min-h-screen bg-[#F5F9F6] text-[#1A2E1A] font-sans selection:bg-green-200">
      <div className="max-w-md mx-auto min-h-screen flex flex-col relative overflow-hidden">
        
        {/* Header */}
        <header className="p-6 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-200">
              <Leaf className="text-white w-6 h-6" />
            </div>
            <span className="font-bold text-xl tracking-tight text-green-900">EcoEarn</span>
          </div>
          {stepIndex > 0 && stepIndex < STEPS.length - 2 && (
            <div className="text-xs font-semibold text-green-700 bg-green-100 px-3 py-1 rounded-full">
              Step {stepIndex} of 5
            </div>
          )}
        </header>

        {/* Main Content */}
        <main className="flex-1 px-6 pb-24 relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              {currentStep.id === 'welcome' && (
                <div className="flex flex-col items-center justify-center h-full text-center py-12">
                  <div className="relative mb-8">
                    <div className="absolute inset-0 bg-green-200 blur-3xl opacity-30 rounded-full" />
                    <img 
                      src="https://picsum.photos/seed/eco-earth/400/400" 
                      alt="Eco Earth" 
                      className="w-64 h-64 object-cover rounded-3xl shadow-2xl relative z-10"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <h1 className="text-4xl font-extrabold text-green-900 mb-4 leading-tight">
                    What's your carbon footprint?
                  </h1>
                  <p className="text-green-700 mb-12 max-w-xs mx-auto leading-relaxed">
                    See how your lifestyle affects the environment and learn how you can earn from reducing it.
                  </p>
                  <button 
                    onClick={nextStep}
                    className="w-full bg-green-600 text-white py-4 rounded-2xl font-bold text-lg shadow-xl shadow-green-200 hover:bg-green-700 transition-all flex items-center justify-center gap-2 group"
                  >
                    Calculate my Footprint
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              )}

              {currentStep.id === 'transport' && (
                <div className="space-y-8 py-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold text-green-900">Transportation</h2>
                    <p className="text-green-600">How do you usually get around?</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {(['car', 'bus', 'bike', 'walk'] as const).map((type) => (
                      <button
                        key={type}
                        onClick={() => updateData('transport', { type })}
                        className={cn(
                          "p-6 rounded-3xl border-2 transition-all flex flex-col items-center gap-3",
                          data.transport.type === type 
                            ? "bg-green-600 border-green-600 text-white shadow-lg shadow-green-100" 
                            : "bg-white border-green-100 text-green-800 hover:border-green-300"
                        )}
                      >
                        {type === 'car' && <Car className="w-8 h-8" />}
                        {type === 'bus' && <Globe className="w-8 h-8" />}
                        {type === 'bike' && <TrendingDown className="w-8 h-8" />}
                        {type === 'walk' && <Leaf className="w-8 h-8" />}
                        <span className="capitalize font-semibold">{type}</span>
                      </button>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <label className="block text-sm font-bold text-green-900 uppercase tracking-wider">
                      Distance per week (km)
                    </label>
                    <input 
                      type="range" 
                      min="0" 
                      max="1000" 
                      value={data.transport.distance}
                      onChange={(e) => updateData('transport', { distance: parseInt(e.target.value) })}
                      className="w-full h-2 bg-green-200 rounded-lg appearance-none cursor-pointer accent-green-600"
                    />
                    <div className="flex justify-between text-lg font-bold text-green-800">
                      <span>0 km</span>
                      <span className="bg-green-100 px-4 py-1 rounded-full">{data.transport.distance} km</span>
                      <span>1000 km</span>
                    </div>
                  </div>

                  {data.transport.type === 'car' && (
                    <div className="flex items-center justify-between p-6 bg-white rounded-3xl border border-green-100">
                      <div className="flex items-center gap-3">
                        <Zap className="text-yellow-500" />
                        <span className="font-bold text-green-900">Is it Electric?</span>
                      </div>
                      <button
                        onClick={() => updateData('transport', { isElectric: !data.transport.isElectric })}
                        className={cn(
                          "w-14 h-8 rounded-full transition-colors relative",
                          data.transport.isElectric ? "bg-green-600" : "bg-gray-200"
                        )}
                      >
                        <div className={cn(
                          "absolute top-1 w-6 h-6 bg-white rounded-full transition-all",
                          data.transport.isElectric ? "left-7" : "left-1"
                        )} />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {currentStep.id === 'diet' && (
                <div className="space-y-8 py-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold text-green-900">Dietary Habits</h2>
                    <p className="text-green-600">Your food choices have a huge impact.</p>
                  </div>

                  <div className="space-y-4">
                    {(['meat', 'vegetarian', 'vegan'] as const).map((type) => (
                      <button
                        key={type}
                        onClick={() => updateData('diet', { type })}
                        className={cn(
                          "w-full p-6 rounded-3xl border-2 transition-all flex items-center justify-between group",
                          data.diet.type === type 
                            ? "bg-green-600 border-green-600 text-white shadow-lg shadow-green-100" 
                            : "bg-white border-green-100 text-green-800 hover:border-green-300"
                        )}
                      >
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "w-12 h-12 rounded-2xl flex items-center justify-center",
                            data.diet.type === type ? "bg-green-500" : "bg-green-50"
                          )}>
                            <Utensils className={cn("w-6 h-6", data.diet.type === type ? "text-white" : "text-green-600")} />
                          </div>
                          <div className="text-left">
                            <p className="font-bold capitalize text-lg">{type}</p>
                            <p className={cn("text-sm", data.diet.type === type ? "text-green-100" : "text-green-500")}>
                              {type === 'meat' ? 'High emission' : type === 'vegetarian' ? 'Medium emission' : 'Low emission'}
                            </p>
                          </div>
                        </div>
                        {data.diet.type === type && <CheckCircle2 className="w-6 h-6" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {currentStep.id === 'energy' && (
                <div className="space-y-8 py-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold text-green-900">Household Energy</h2>
                    <p className="text-green-600">Monthly utility consumption.</p>
                  </div>

                  <div className="space-y-6">
                    <div className="p-6 bg-white rounded-3xl border border-green-100 space-y-4">
                      <div className="flex items-center gap-3 mb-2">
                        <Zap className="text-yellow-500" />
                        <span className="font-bold text-green-900">Electricity (kWh)</span>
                      </div>
                      <input 
                        type="number"
                        value={data.energy.electricity}
                        onChange={(e) => updateData('energy', { electricity: parseInt(e.target.value) || 0 })}
                        className="w-full bg-green-50 border-none rounded-2xl p-4 text-xl font-bold text-green-900 focus:ring-2 focus:ring-green-500 outline-none"
                        placeholder="200"
                      />
                    </div>

                    <div className="p-6 bg-white rounded-3xl border border-green-100 space-y-4">
                      <div className="flex items-center gap-3 mb-2">
                        <Globe className="text-blue-500" />
                        <span className="font-bold text-green-900">Natural Gas (Units)</span>
                      </div>
                      <input 
                        type="number"
                        value={data.energy.gas}
                        onChange={(e) => updateData('energy', { gas: parseInt(e.target.value) || 0 })}
                        className="w-full bg-green-50 border-none rounded-2xl p-4 text-xl font-bold text-green-900 focus:ring-2 focus:ring-green-500 outline-none"
                        placeholder="10"
                      />
                    </div>
                  </div>
                </div>
              )}

              {currentStep.id === 'waste' && (
                <div className="space-y-8 py-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold text-green-900">Waste Management</h2>
                    <p className="text-green-600">How much do you recycle?</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    {(['none', 'partial', 'full'] as const).map((level) => (
                      <button
                        key={level}
                        onClick={() => updateData('waste', { recycleLevel: level })}
                        className={cn(
                          "p-6 rounded-3xl border-2 transition-all flex items-center gap-4",
                          data.waste.recycleLevel === level 
                            ? "bg-green-600 border-green-600 text-white shadow-lg shadow-green-100" 
                            : "bg-white border-green-100 text-green-800 hover:border-green-300"
                        )}
                      >
                        <div className={cn(
                          "w-12 h-12 rounded-2xl flex items-center justify-center",
                          data.waste.recycleLevel === level ? "bg-green-500" : "bg-green-50"
                        )}>
                          <Trash2 className={cn("w-6 h-6", data.waste.recycleLevel === level ? "text-white" : "text-green-600")} />
                        </div>
                        <div className="text-left">
                          <span className="font-bold capitalize text-lg">{level} Recycling</span>
                          <p className={cn("text-sm", data.waste.recycleLevel === level ? "text-green-100" : "text-green-500")}>
                            {level === 'none' ? 'High waste' : level === 'partial' ? 'Moderate waste' : 'Minimal waste'}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {currentStep.id === 'flights' && (
                <div className="space-y-8 py-4">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold text-green-900">Air Travel</h2>
                    <p className="text-green-600">Total flight hours per year.</p>
                  </div>

                  <div className="p-8 bg-white rounded-[40px] border border-green-100 flex flex-col items-center text-center space-y-6">
                    <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center">
                      <Plane className="w-10 h-10 text-blue-600" />
                    </div>
                    <div>
                      <span className="text-5xl font-black text-green-900">{data.flights.hours}</span>
                      <span className="text-xl font-bold text-green-600 ml-2">hrs/yr</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="200" 
                      value={data.flights.hours}
                      onChange={(e) => updateData('flights', { hours: parseInt(e.target.value) })}
                      className="w-full h-3 bg-green-100 rounded-lg appearance-none cursor-pointer accent-green-600"
                    />
                    <p className="text-sm text-green-500 italic">
                      Includes domestic and international flights.
                    </p>
                  </div>
                </div>
              )}

              {currentStep.id === 'results' && (
                <div className="space-y-6 py-4">
                  <div className="text-center space-y-2">
                    <h2 className="text-2xl font-bold text-green-900">My Carbon Footprint</h2>
                    <div className="relative inline-block">
                      <span className="text-6xl font-black text-green-600">{results.totalTons}</span>
                      <span className="absolute -right-12 bottom-2 text-sm font-bold text-green-800 bg-green-100 px-2 py-0.5 rounded">Tons CO2</span>
                    </div>
                    <p className="text-green-600 font-medium">Your annual estimated emissions</p>
                  </div>

                  <div className="h-64 w-full bg-white rounded-[40px] p-4 shadow-sm border border-green-50">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={results.breakdown}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {results.breakdown.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {results.breakdown.map((item) => (
                      <div key={item.name} className="bg-white p-4 rounded-2xl border border-green-50 flex items-center gap-3">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-green-900">{item.name}</span>
                          <span className="text-xs text-green-500">{Math.round(item.value)} kg</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-green-900 text-white p-6 rounded-[32px] space-y-4 shadow-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Wallet className="w-5 h-5 text-green-400" />
                        <span className="font-bold">Potential Earnings</span>
                      </div>
                      <span className="bg-green-800 px-3 py-1 rounded-full text-xs font-bold">Carbon Credits</span>
                    </div>
                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-3xl font-black">₹{results.marketValueInINR.toLocaleString()}</p>
                        <p className="text-xs text-green-300">Based on {results.creditsEarnable} credits</p>
                      </div>
                      <button 
                        onClick={nextStep}
                        className="bg-green-500 hover:bg-green-400 text-green-950 px-4 py-2 rounded-xl font-bold text-sm transition-colors"
                      >
                        Sell Now
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {currentStep.id === 'marketplace' && (
                <div className="space-y-6 py-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-green-900">Marketplace</h2>
                    <div className="flex items-center gap-1 text-green-600 bg-green-100 px-3 py-1 rounded-full text-xs font-bold">
                      <TrendingDown className="w-3 h-3" />
                      <span>+4.2% Today</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-white p-6 rounded-[32px] border border-green-100 shadow-sm">
                      <p className="text-sm font-bold text-green-500 uppercase tracking-widest mb-1">Current Balance</p>
                      <div className="flex items-center justify-between">
                        <h3 className="text-3xl font-black text-green-900">{results.creditsEarnable} <span className="text-lg font-bold text-green-600">Credits</span></h3>
                        <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                          <Leaf className="text-green-600" />
                        </div>
                      </div>
                    </div>

                    <h3 className="font-bold text-green-900 px-2">Active ESG Buyers</h3>
                    
                    <div className="space-y-3">
                      {[
                        { name: 'Tata Power ESG', price: '₹2,450', rating: 'AAA', logo: 'TP' },
                        { name: 'Reliance Green', price: '₹2,380', rating: 'AA+', logo: 'RG' },
                        { name: 'Adani Renewables', price: '₹2,410', rating: 'AAA', logo: 'AR' },
                      ].map((buyer) => (
                        <div key={buyer.name} className="bg-white p-4 rounded-3xl border border-green-50 flex items-center justify-between hover:border-green-200 transition-all cursor-pointer group">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-green-900 text-white rounded-2xl flex items-center justify-center font-bold">
                              {buyer.logo}
                            </div>
                            <div>
                              <p className="font-bold text-green-900">{buyer.name}</p>
                              <p className="text-xs text-green-500">Rating: <span className="text-green-700 font-bold">{buyer.rating}</span></p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-black text-green-600">{buyer.price}</p>
                            <p className="text-[10px] text-green-400 font-bold">PER CREDIT</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="p-6 bg-green-100 rounded-[32px] border border-green-200 flex items-center gap-4">
                      <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center flex-shrink-0">
                        <Info className="text-green-600 w-5 h-5" />
                      </div>
                      <p className="text-xs text-green-800 leading-relaxed">
                        EcoEarn is the <strong>Zerodha of Carbon Credits</strong>. We connect your verified reductions directly to corporate buyers.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Navigation Bar */}
        {stepIndex > 0 && (
          <footer className="fixed bottom-0 left-0 right-0 max-w-md mx-auto p-6 bg-gradient-to-t from-[#F5F9F6] via-[#F5F9F6] to-transparent z-20">
            <div className="flex gap-4">
              {stepIndex < STEPS.length - 1 && (
                <button 
                  onClick={prevStep}
                  className="w-16 h-16 bg-white border border-green-100 rounded-2xl flex items-center justify-center text-green-800 shadow-lg hover:bg-green-50 transition-all"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
              )}
              
              {stepIndex < STEPS.length - 2 ? (
                <button 
                  onClick={nextStep}
                  className="flex-1 bg-green-600 text-white rounded-2xl font-bold text-lg shadow-xl shadow-green-200 hover:bg-green-700 transition-all flex items-center justify-center gap-2"
                >
                  Continue to {STEPS[stepIndex + 1].title}
                  <ChevronRight className="w-5 h-5" />
                </button>
              ) : stepIndex === STEPS.length - 2 ? (
                <button 
                  onClick={nextStep}
                  className="flex-1 bg-green-900 text-white rounded-2xl font-bold text-lg shadow-xl shadow-green-900/20 hover:bg-black transition-all flex items-center justify-center gap-2"
                >
                  Go to Marketplace
                  <Wallet className="w-5 h-5" />
                </button>
              ) : (
                <button 
                  onClick={() => setStepIndex(0)}
                  className="flex-1 bg-green-600 text-white rounded-2xl font-bold text-lg shadow-xl shadow-green-200 hover:bg-green-700 transition-all flex items-center justify-center gap-2"
                >
                  Recalculate
                  <TrendingDown className="w-5 h-5" />
                </button>
              )}
            </div>
          </footer>
        )}

        {/* Background Decorative Elements */}
        <div className="absolute top-[-10%] right-[-10%] w-64 h-64 bg-green-200 rounded-full blur-[100px] opacity-20 pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-10%] w-64 h-64 bg-green-300 rounded-full blur-[100px] opacity-20 pointer-events-none" />
      </div>
    </div>
  );
}
