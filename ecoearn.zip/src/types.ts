export interface CarbonData {
  transport: {
    type: 'car' | 'bus' | 'bike' | 'walk';
    distance: number; // km per week
    isElectric: boolean;
  };
  diet: {
    type: 'meat' | 'vegetarian' | 'vegan';
  };
  energy: {
    electricity: number; // kWh per month
    gas: number; // units per month
  };
  waste: {
    recycleLevel: 'none' | 'partial' | 'full';
  };
  flights: {
    hours: number; // per year
  };
}

export interface FootprintResult {
  totalTons: number;
  breakdown: {
    name: string;
    value: number;
    color: string;
  }[];
  creditsEarnable: number;
  marketValueInINR: number;
}
