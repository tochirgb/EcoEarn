import { CarbonData, FootprintResult } from "./types";

// Emission factors (kg CO2 per unit) - Simplified averages
const FACTORS = {
  transport: {
    car: 0.18, // per km
    bus: 0.08, // per km
    bike: 0.01,
    walk: 0,
    electricDiscount: 0.6, // 60% reduction for EV
  },
  diet: {
    meat: 2500, // kg per year
    vegetarian: 1500,
    vegan: 1000,
  },
  energy: {
    electricity: 0.85, // kg per kWh
    gas: 2.0, // kg per unit
  },
  waste: {
    none: 500, // kg per year
    partial: 300,
    full: 100,
  },
  flights: {
    perHour: 90, // kg per flight hour
  }
};

export function calculateFootprint(data: CarbonData): FootprintResult {
  // Transport (Annual)
  let transportKg = data.transport.distance * 52 * FACTORS.transport[data.transport.type];
  if (data.transport.isElectric) transportKg *= (1 - FACTORS.transport.electricDiscount);

  // Diet (Annual)
  const dietKg = FACTORS.diet[data.diet.type];

  // Energy (Annual)
  const energyKg = (data.energy.electricity * FACTORS.energy.electricity + data.energy.gas * FACTORS.energy.gas) * 12;

  // Waste (Annual)
  const wasteKg = FACTORS.waste[data.waste.recycleLevel];

  // Flights (Annual)
  const flightsKg = data.flights.hours * FACTORS.flights.perHour;

  const totalKg = transportKg + dietKg + energyKg + wasteKg + flightsKg;
  const totalTons = totalKg / 1000;

  // Average Indian footprint is ~1.9 tons, Global average ~4.7 tons
  // Credits earnable if user is below a "target" or by specific actions
  // For this app, let's say credits = (Average - User) if User < Average, else 0
  const averageTons = 5.0; // Benchmark
  const creditsEarnable = Math.max(0, averageTons - totalTons);
  const marketValueInINR = creditsEarnable * 2200; // ~₹2200 per credit

  return {
    totalTons: parseFloat(totalTons.toFixed(2)),
    breakdown: [
      { name: 'Transport', value: Math.round(transportKg), color: '#22c55e' },
      { name: 'Diet', value: Math.round(dietKg), color: '#16a34a' },
      { name: 'Energy', value: Math.round(energyKg), color: '#15803d' },
      { name: 'Waste', value: Math.round(wasteKg), color: '#166534' },
      { name: 'Flights', value: Math.round(flightsKg), color: '#14532d' },
    ],
    creditsEarnable: parseFloat(creditsEarnable.toFixed(2)),
    marketValueInINR: Math.round(marketValueInINR),
  };
}
